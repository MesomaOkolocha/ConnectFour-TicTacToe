"""
Author: Mesoma Okolocha
Lab:10
File: connectFourGUI.py

Displays a window with multiple buttons and plays the connect four game.
"""

from breezypythongui import EasyFrame
from tkinter import PhotoImage
from connectFour import ConnectFour

class ConnectFourGUI(EasyFrame):

   def __init__(self):
      """Creates the connect four game, sets up labels for each play space,
      buttons for each column, a current turn label, and a restart button."""
      super().__init__(title = "Connect Four!")
      self.game = ConnectFour()
      
      self.setSize(64 * len(self.game.board), 64 * len(self.game.board[0]))
      
      self.tokenImages = {
         "R" : PhotoImage(file = "red.png"),
         "Y" : PhotoImage(file = "yellow.png"),
         " " : PhotoImage(file = "empty.png")
      }
      
      
      self.stateLabel = self.addLabel("Turn:", row = len(self.game.board) + 2, column = 0)
      self.turnLabel= self.addLabel("", row = len(self.game.board) + 2, column = 1)
      
      self.boardLabels = []
      
      for row in range(len(self.game.board)):
         self.boardLabels.append([])
         for column in range(len(self.game.board[row])):
            self.boardLabels[row].append(self.addLabel("", row=row, column=column))
      
      self.setBoardLabels()
      
      self.columnButtons = []
      # Create a column button for each column, place them in the row len(self.game.board) + 2
      for column in range(len(self.game.board[0])):
         self.columnButtons.append(self.addButton(row=len(self.game.board)+1,column=column,
                                                  text="{:^10d}".format(column),command=self.makeColumnFunction(column)))
      
      # Set the text of each one to the column number with "{:^10d}".format() to center the numbers
      # Set the command with the self.makeColumnFunction() method
      # Set the state to "normal"
   
      # Add a new game button to invoke self.newGame, with its state initially set to "disabled"
      self.newGameButton=self.addButton(row=len(self.game.board)+2, column=len(self.game.board)-1, text="New game",
                                  command=self.newGame,state="disabled",columnspan=2)
      # Recommended columnspan is 2
      
      
   def makeColumnFunction(self, column):
      """Creates a function application using the column to pass as an argument
      to self.nextMove. Used by self.columnButtons."""
      
      return lambda: self.nextMove(column)
      
      
   def setBoardLabels(self):
      # Set the matching row,column label in boardLabels to the
      for row in range(len(self.game.board)):
         for column in range(len(self.game.board[row])):
            self.boardLabels[row][column]["image"]=self.tokenImages[self.game.board[row][column]]
         
      
      # appropriate image based on self.game.board's row,column
        
      # Set the image of the turnLabel to the correct image based on self.game.getTurn()
      self.turnLabel["image"]=self.tokenImages[self.game.getTurn()]
      
      # Temporary pass statement
      
      

   def nextMove(self, column):
      """Makes a move in the game and updates the view with
      the results."""
      
      
      # Call the step on the game with the given column
      self.game.step(column)
      
      self.setBoardLabels()
      
      # If the game is over, use self.messageBox to indicate who won, and
      if self.game.isGameOver():
         self.messageBox("Game over!",self.game.getTurn() + " Won!")
         for button in self.columnButtons:
            button["state"]="disabled"
         self.newGameButton["state"]="normal"
         
      #  set the state of all column buttons to "disabled", and set the
      #  state of the new game button to "normal"

   def newGame(self):
      """Create a new connect four game and updates the view."""
      # Set self.game to a new connect four game
      self.game=ConnectFour()
      self.setBoardLabels()
      
      # Set the state of the new game button to "disabled"
      self.newGameButton["state"]="disabled"
      # Set the state of all column buttons to "normal"
      for button in self.columnButtons:
            button["state"]="normal"

def main():
   app = ConnectFourGUI()
   app.mainloop()

if __name__ == "__main__":
   main()
